import{g as a,a as e,c as t}from"./index-BZni0hBG.js";const n={renderer:t,...e,...a};var o=n;export{o as default};
